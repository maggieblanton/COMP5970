import UIKit

func calculateLoan(_ loanAmount: Double, _ numOfPayments : Double, _ interestRate: Double)-> Double {
    var total: Double

  
    total = loanAmount * (interestRate / 100) * pow((1 + interestRate / 100), numOfPayments) / (pow((1 + interestRate / 100), numOfPayments) - 1)

    return total
}

print(calculateLoan(20000, 72, (4.4 / 12)))
print(calculateLoan(150000, 30, 5))



