//
//  ViewController.swift
//  comp5970_assignment2a
//
//  Created by Maggie Blanton on 6/19/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var loanAmount: UITextField!
    
    @IBOutlet weak var numOfPayments: UITextField!
    
    @IBOutlet weak var interestRate: UITextField!
    
    @IBOutlet weak var total: UITextField!
    
    @IBAction func calculate(_ sender: UIButton) {
        
        var paymentNum: Double = Double(numOfPayments.text!)!
        var rate: Double = Double(interestRate.text!)!
        var amount: Double = Double(loanAmount.text!)!
        
        if (paymentNum == 0 && amount != 0 || paymentNum == nil) {
            total.text = "invalid input"
        }
        else if (amount == 0) {
            total.text = "$0.00"
        }
        else {
        
            var totalAmount: Double = amount * (rate / 100) * pow((1 + rate / 100), paymentNum) / (pow((1 + rate / 100), paymentNum) - 1)
            total.text = "$ " + String(round(100*totalAmount)/100)
        }
        
        
        
    }
    
    
}

