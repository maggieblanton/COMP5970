//
//  TableViewController.swift
//  comp5970_assignment3b
//
//  Created by Maggie Blanton on 7/28/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit


class TableViewController: UITableViewController {

    var albums = [Album]()

    private func startup() {
        
        guard let album1 = Album(name: "Goodbye Yellow Brick Road", artist: "Elton John", year: "1973", record: "MCA", cover: UIImage(named:"cover1")) else {
            fatalError()
        }
        
        guard let album2 = Album(name: "Sweet Baby James", artist: "James Taylor", year: "1970", record: "Sunset Sound", cover: UIImage(named: "cover2")) else {
            fatalError()
        }
        guard let album3 = Album(name: "The Stranger", artist: "Billy Joel", year: "1977", record: "Columbia Records", cover: UIImage(named:"cover3")) else {
            fatalError()
        }
        guard let album4 = Album(name: "folklore", artist: "Taylor Swift", year: "2020", record: "Republic Records", cover: UIImage(named:"cover4")) else {
            fatalError()
        }
        guard let album5 = Album(name: "Dreamin' Out Loud", artist: "Trace Adkins", year: "1996", record: "Capitol Nashville", cover: UIImage(named:"cover5")) else {
            fatalError()
        }
        guard let album6 = Album(name: "Room For Squares", artist: "John Mayer", year: "2001", record: "Columbia Records", cover: UIImage(named:"cover6")) else {
            fatalError()
        }
        guard let album7 = Album(name: "People", artist: "Hillsong United", year: "2018", record: "HIL", cover: UIImage(named:"cover7")) else {
            fatalError()
        }
        guard let album8 = Album(name: "Golden Hour", artist: "Kacey Musgraves", year: "2018", record: "MCA Nashville", cover: UIImage(named:"cover8")) else {
            fatalError()
        }
        guard let album9 = Album(name: "You Don't Bring Me Flowers", artist: "Neil Diamond", year: "1978", record: "Columbia Records", cover: UIImage(named: "cover9")) else {
            fatalError()
        }
        guard let album10 = Album(name: "In Between Dreams", artist: "Jack Johnson", year: "2005", record: "Brushfire Records", cover: UIImage(named: "cover10")) else {
            fatalError()
        }
        

        albums += [album1, album2, album3, album4, album5, album6, album7, album8, album9 ,album10]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return albums.count
    }
    
    private func saveAlbums() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(albums, toFile: Album.ArchiveURL.path)
       
    }
    
    private func loadAlbums() -> [Album]?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Album.ArchiveURL.path) as? [Album]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let savedAlbums = loadAlbums() {
            albums += savedAlbums
        }
        else {
            startup()
        }
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier =  "TableViewCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! TableViewCell
        let album = albums[indexPath.row]
        cell.albumLabel.text = album.name
        cell.coverImageView.image = album.cover
        cell.artistLabel.text = album.artist
        return cell
    }

  
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

   override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            albums.remove(at: indexPath.row)
            saveAlbums()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
          
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
            if segue.identifer ?? "" ==  "add" {
            print("Adding item")
            }
            if segue.identifier == "detail" {
            guard let albumDetailViewController = segue.destination as? ViewController else {
                fatalError()
            }
            guard let selectedAlbumCell = sender as? TableViewCell else {
                fatalError()
            }
            guard let indexPath = tableView.indexPath(for: selectedAlbumCell) else {
                fatalError()
            }
            let selectedAlbum = albums[indexPath.row]
            albumDetailViewController.album = selectedAlbum
            }
        
        }
    }
    
    @IBAction func revertBack(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? ViewController, let album = sourceViewController.album {
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                albums[selectedIndexPath.row] = album
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
            }
            else {
                let newIndexPath = IndexPath(row: albums.count, section: 0)
                albums.append(album)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
            
            saveAlbums()
        }
    }
}

class Album: NSObject, NSCoding {
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: PropertyKey.name)
        aCoder.encode(artist, forKey: PropertyKey.artist)
        aCoder.encode(year, forKey: PropertyKey.year)
        aCoder.encode(record, forKey: PropertyKey.record)
        aCoder.encode(cover, forKey: PropertyKey.cover)
   
    }
    
    
    var name: String
    var artist: String
    var year: String
    var record: String
    var cover: UIImage?
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("albumApp")

 
    struct PropertyKey {
        static let name = "title"
        static let artist = "artist"
        static let year = "year"
        static let record = "record"
        static let cover = "cover"
    }
    

    init?(name: String, artist: String, year: String, record: String, cover: UIImage?) {
        
        if name.isEmpty || artist.isEmpty || year.isEmpty || record.isEmpty {
            return nil
        }
        
        self.name = name
        self.artist = artist
        self.year = year
        self.record = record
        self.cover = cover
        
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
           guard let name = aDecoder.decodeObject(forKey: PropertyKey.name) as? String else {
               return nil
           }
           
           guard let artist = aDecoder.decodeObject(forKey: PropertyKey.artist) as? String else {
               return nil
           }
     
           guard let cover = aDecoder.decodeObject(forKey: PropertyKey.cover) as? UIImage else {
               return nil
           }
           
           guard let year = aDecoder.decodeObject(forKey: PropertyKey.year) as? String else {
               return nil
           }
       
           let record = aDecoder.decodeObject(forKey: PropertyKey.record) as? String

           self.init(name: name, artist: artist, year: year, record: record!, cover: cover)
       }
}

class TableViewCell: UITableViewCell {

    @IBOutlet weak var coverImageView: UIImageView!
    @IBOutlet weak var albumLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
