//
//  ViewController.swift
//  comp5970_assignment3b
//
//  Created by Maggie Blanton on 7/28/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//


import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var albumCover: UIImageView!

    @IBOutlet weak var albumLabel: UITextField!
    @IBOutlet weak var artistLabel: UITextField!
    @IBOutlet weak var releasedYear: UITextField!
    @IBOutlet weak var recordLabel: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var album: Album?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        albumLabel.delegate = self
        artistLabel.delegate = self
        releasedYear.delegate = self
        recordLabel.delegate = self

        if let album = album {
           
            navigationItem.title = album.name
            albumLabel.text = album.name
            artistLabel.text = album.artist
            releasedYear.text = album.year
            albumCover.image = album.cover
            recordLabel.text = album.record
        }
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
   
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
  func imagePickerController(_ picker: UIImagePickerController,
         didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

           if let selectedImage = info[.originalImage] as? UIImage {
                albumCover.image = selectedImage
            
           } else {
                print("Error: \(info)")
           }
              dismiss(animated: true, completion: nil)
          }
    
   @IBAction func cancel(_ sender: UIBarButtonItem) {
        
       if presentingViewController is UINavigationController {
        dismiss(animated: true, completion: nil)
        }
       else if let owningNavigationController = navigationController{
           owningNavigationController.popViewController(animated: true)
        }
       else {
            fatalError()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        let name = albumLabel.text
        let artist = artistLabel.text
        let year = releasedYear.text ?? ""
        let record = recordLabel.text ?? ""
        let cover = albumCover.image
        
        album = Album(name: name!, artist: artist!, year: year, record: record, cover: cover)
    }
     
    @IBAction func selectCoverFromPhotoLibrary(_ sender: Any) {
        albumLabel.resignFirstResponder()
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
        
    }
    
}

