//
//  ViewController.swift
//  comp5970-assignment1c
//
//  Created by Maggie Blanton on 6/10/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var auburnImage: UIImageView!
    
    @IBOutlet weak var alabamaImage: UIImageView!
    
    
    @IBAction func slider(_ sender: UISlider) {
        auburnImage.alpha = CGFloat((1.0 - sender.value))
        alabamaImage.alpha = CGFloat(sender.value)
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        auburnImage.image = UIImage(named: "auburnLogo")
        auburnImage.alpha = 0.5
        alabamaImage.image = UIImage(named: "alabamaLogo")
        alabamaImage.alpha = 0.5
    }
    


}

