//
//  ViewController2.swift
//  finalProject
//
//  Created by Maggie Blanton on 7/1/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    var name2 = " "

   
    @IBOutlet var button1: UIButton!
    
    @IBOutlet var button2: UIButton!
    
    @IBOutlet weak var schoolLogo: UIImageView!
    
    override func viewDidLoad() {
           super.viewDidLoad()
           if name2 == "Alabama" {
               schoolLogo.image = UIImage(named: "alabamaLogo")
                self.view.backgroundColor = UIColor(red: 0.65, green: 0.05, blue: 0.19, alpha: 1.00)
                button1.backgroundColor = .white
                button1.setTitleColor(.black, for: .normal)
                button2.backgroundColor = .white
                button2.setTitleColor(.black, for: .normal)
           }
           else if name2 == "Auburn" {
               schoolLogo.image = UIImage(named: "auburnLogo")
                self.view.backgroundColor = UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00)
                button1.backgroundColor = UIColor(red: 0.97, green: 0.40, blue: 0.13, alpha: 1.00)
                button1.setTitleColor(UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00), for: .normal)
                button2.backgroundColor = UIColor(red: 0.97, green: 0.40, blue: 0.13, alpha: 1.00)
                button2.setTitleColor(UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00), for: .normal)
                
           }
           else if name2 == "Arkansas" {
               schoolLogo.image = UIImage(named: "arkansasLogo")
                self.view.backgroundColor = UIColor(red: 0.62, green: 0.13, blue: 0.21, alpha: 1.00)
                button1.backgroundColor = .white
                button1.setTitleColor(.black, for: .normal)
                button2.backgroundColor = .white
                button2.setTitleColor(.black, for: .normal)
           }
           else if name2 == "Ole Miss"{
                schoolLogo.image = UIImage(named: "oleMissLogo")
                self.view.backgroundColor = UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00)
                button1.backgroundColor = UIColor(red: 0.98, green: 0.00, blue: 0.24, alpha: 1.00)
                button1.setTitleColor(UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00), for: .normal)
                button2.backgroundColor = UIColor(red: 0.98, green: 0.00, blue: 0.24, alpha: 1.00)
                button2.setTitleColor(UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00), for: .normal)
           }
           else if name2 == "Mississippi State" {
                schoolLogo.image = UIImage(named: "missStateLogo")
                self.view.backgroundColor = UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00)
                button1.backgroundColor = .white
                button1.setTitleColor(UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00), for: .normal)
                button2.backgroundColor = .white
                button2.setTitleColor(UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00), for: .normal)
                
           }
           else if name2 == "Kentucky" {
                schoolLogo.image = UIImage(named: "kentuckyLogo")
                self.view.backgroundColor = UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00)
                button1.backgroundColor = .white
                button1.setTitleColor(UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00), for: .normal)
                button2.backgroundColor = .white
                button2.setTitleColor(UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00), for: .normal)
            }
           else if name2 == "Tennessee" {
                schoolLogo.image = UIImage(named: "tennesseeLogo")
                self.view.backgroundColor = .white
                button1.backgroundColor = UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00)
                button1.setTitleColor(.white, for: .normal)
                button2.backgroundColor = UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00)
                button2.setTitleColor(.white, for: .normal)
                
           }
           else if name2 == "South Carolina" {
                schoolLogo.image = UIImage(named: "southCarolinaLogo")
                self.view.backgroundColor = UIColor(red: 0.45, green: 0.00, blue: 0.04, alpha: 1.00)
                button1.backgroundColor = .white
                button1.setTitleColor(.black, for: .normal)
                button2.backgroundColor = .white
                button2.setTitleColor(.black, for: .normal)
           }
           else if name2 == "Missouri" {
               schoolLogo.image = UIImage(named: "missouriLogo")
                self.view.backgroundColor = .black
                button1.backgroundColor = UIColor(red: 0.97, green: 0.82, blue: 0.28, alpha: 1.00)
                button1.setTitleColor(.black, for: .normal)
                button2.backgroundColor = UIColor(red: 0.97, green: 0.82, blue: 0.28, alpha: 1.00)
                button2.setTitleColor(.black, for: .normal)
           }
           else if name2 == "LSU" {
               schoolLogo.image = UIImage(named: "lsuLogo")
                self.view.backgroundColor = UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00)
                button1.backgroundColor = UIColor(red: 0.96, green: 0.85, blue: 0.42, alpha: 1.00)
                button1.setTitleColor(UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00), for: .normal)
                button2.backgroundColor = UIColor(red: 0.96, green: 0.85, blue: 0.42, alpha: 1.00)
                button2.setTitleColor(UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00), for: .normal)
           }
            else if name2 == "Florida" {
               schoolLogo.image = UIImage(named: "floridaLogo")
                self.view.backgroundColor = UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00)
                button1.backgroundColor = UIColor(red: 0.98, green: 0.34, blue: 0.09, alpha: 1.00)
                button1.setTitleColor(UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00), for: .normal)
                button2.backgroundColor = UIColor(red: 0.98, green: 0.34, blue: 0.09, alpha: 1.00)
                button2.setTitleColor(UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00), for: .normal)
                
            }
            else if name2 == "Georgia" {
               schoolLogo.image = UIImage(named: "georgiaLogo")
                self.view.backgroundColor = UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00)
                button1.backgroundColor = UIColor(red: 0.73, green: 0.01, blue: 0.16, alpha: 1.00)
                button1.setTitleColor(UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00), for: .normal)
                button2.backgroundColor = UIColor(red: 0.73, green: 0.01, blue: 0.16, alpha: 1.00)
                button2.setTitleColor(UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00), for: .normal)
                
               
            }
            else if name2 == "Texas A&M" {
                schoolLogo.image = UIImage(named: "texasAMLogo")
                self.view.backgroundColor = .white
                button1.backgroundColor = UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00)
                button1.setTitleColor(.white, for: .normal)
                button2.backgroundColor = UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00)
                button2.setTitleColor(.white, for: .normal)
                
            }
            else if name2 == "Vanderbilt" {
                schoolLogo.image = UIImage(named: "vanderbiltLogo")
                self.view.backgroundColor = .black
                button1.backgroundColor = UIColor(red: 0.70, green: 0.63, blue: 0.46, alpha: 1.00)
                button1.setTitleColor(.black, for: .normal)
                button2.backgroundColor = UIColor(red: 0.70, green: 0.63, blue: 0.46, alpha: 1.00)
                button2.setTitleColor(.black, for: .normal)
            }

           // Do any additional setup after loading the view.
       }
    
    @IBAction func raiseGPA(_ sender: Any) {
         performSegue(withIdentifier: "raise", sender: self)
    }
    
    @IBAction func calculateGPA(_ sender: Any) {
        performSegue(withIdentifier: "calculate", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch(segue.identifier ?? "") {
        case "calculate":
            let view = segue.destination as! ViewController3
            view.name3 = self.name2
        case "raise":
            let view = segue.destination as! ViewController4
            view.name3 = self.name2
        default:
            print("Do nothing")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
