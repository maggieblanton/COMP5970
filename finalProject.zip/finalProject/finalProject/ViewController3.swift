//
//  ViewController3.swift
//  finalProject
//
//  Created by Maggie Blanton on 7/1/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController3: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    
    @IBOutlet var calculateButton: UIButton!
    
    var name3 = " "
    var grade1 = " ", grade2 = " ", grade3 = " " , grade4 = " ", grade5 = " ", grade6 = " "
    var cv1: Double = 0.0, cv2: Double = 0.0, cv3: Double = 0.0, cv4: Double = 0.0, cv5: Double = 0.0, cv6: Double = 0.0, iGPA: Double = 0.0, credit: Double = 0.0

    
    @IBOutlet weak var cumulativeGPA: UITextField!
    @IBOutlet weak var totalCredits: UITextField!
    @IBOutlet weak var semesterGPA: UITextField!
    @IBOutlet weak var updatedGPA: UITextField!
    
    @IBOutlet var scrollView: UIView!
    @IBOutlet weak var credit1: UITextField!
    @IBOutlet weak var credit2: UITextField!
    @IBOutlet weak var credit3: UITextField!
    @IBOutlet weak var credit4: UITextField!
    @IBOutlet weak var credit5: UITextField!
    @IBOutlet weak var credit6: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print (name3)
        self.cumulativeGPA.delegate = self
        self.totalCredits.delegate = self
        self.semesterGPA.delegate = self
        self.updatedGPA.delegate = self
        self.credit1.delegate = self
        self.credit2.delegate = self
        self.credit3.delegate = self
        self.credit4.delegate = self
        self.credit5.delegate = self
        self.credit6.delegate = self
        
        if name3 == "Alabama" || name3 == "LSU" {
            grade1 = "A+"; grade2 = "A+"; grade3 = "A+"; grade4 = "A+"; grade5 = "A+"; grade6 = "A+"
        }
        else {
            grade1 = "A"; grade2 = "A"; grade3 = "A"; grade4 = "A"; grade5 = "A"; grade6 = "A"
        }
        
        credit1.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credit2.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credit3.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credit4.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credit5.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credit6.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        cumulativeGPA.attributedPlaceholder = NSAttributedString(string: "0.00", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        totalCredits.attributedPlaceholder = NSAttributedString(string: "0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        
        
        credit1.backgroundColor = .white
        credit2.backgroundColor = .white
        credit3.backgroundColor = .white
        credit4.backgroundColor = .white
        credit5.backgroundColor = .white
        credit6.backgroundColor = .white
        cumulativeGPA.backgroundColor = .white
        totalCredits.backgroundColor = .white
        semesterGPA.backgroundColor = .white
        updatedGPA.backgroundColor = .white
        picker1.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        picker2.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        picker3.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        picker4.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        picker5.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        picker6.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        
        
        if name3 == "Alabama" {
            scrollView.backgroundColor = UIColor(red: 0.65, green: 0.05, blue: 0.19, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(.black, for: .normal)
        }
        if name3 == "Arkansas" {
            scrollView.backgroundColor = UIColor(red: 0.62, green: 0.13, blue: 0.21, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(.black, for: .normal)
        }
        if name3 == "Auburn" {
            scrollView.backgroundColor = UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.97, green: 0.40, blue: 0.13, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00), for: .normal)
        }
        if name3 == "Florida" {
            scrollView.backgroundColor = UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.98, green: 0.34, blue: 0.09, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00), for: .normal)
        }
        if name3 == "Georgia" {
            scrollView.backgroundColor = UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.73, green: 0.01, blue: 0.16, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00), for: .normal)
        }
        if name3 == "Kentucky" {
            scrollView.backgroundColor = UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00), for: .normal)
        }
        if name3 == "LSU" {
            scrollView.backgroundColor = UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.96, green: 0.85, blue: 0.42, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00), for: .normal)
        }
        if name3 == "Mississippi State" {
            scrollView.backgroundColor = UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00), for: .normal)
            
        }
        if name3 == "Missouri" {
            scrollView.backgroundColor = .black
            calculateButton.backgroundColor = UIColor(red: 0.97, green: 0.82, blue: 0.28, alpha: 1.00)
            calculateButton.setTitleColor(.black, for: .normal)
            
        }
        if name3 == "Ole Miss" {
            scrollView.backgroundColor = UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.98, green: 0.00, blue: 0.24, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00), for: .normal)
        }
        if name3 == "South Carolina" {
            scrollView.backgroundColor = UIColor(red: 0.45, green: 0.00, blue: 0.04, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(.black, for: .normal)
        }
        if name3 == "Tennessee" {
            scrollView.backgroundColor = UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00), for: .normal)
        }
        if name3 == "Texas A&M" {
            scrollView.backgroundColor = UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00), for: .normal)
        }
        if name3 == "Vanderbilt" {
            scrollView.backgroundColor = .black
            calculateButton.backgroundColor = UIColor(red: 0.70, green: 0.63, blue: 0.46, alpha: 1.00)
            calculateButton.setTitleColor(.black, for: .normal)
        }
        
   
          let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
            tap.cancelsTouchesInView = false
            view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
    @objc func dismissKeyboard() {
        
        view.endEditing(true)
    }
    
    
    
    // UA, LSU
    let grades1 = ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D-", "F"];
    // Arkansas, Kentucky, Missouri, Tennessee, & Vanderbilt
    let grades2 = ["A","A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"];
    // Georgia, Ole Miss
    let grades3 = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"];
    // Auburn, Texas A&M, Mississippi State
    let grades4 = ["A", "B","C", "D", "F"];
    // Florida, South Carolina
    let grades5 = ["A", "B+", "B", "C+", "C", "D+", "D", "F"]
    
    
    @IBOutlet weak var picker1: UIPickerView!
    @IBOutlet weak var picker2: UIPickerView!
    @IBOutlet weak var picker3: UIPickerView!
    @IBOutlet weak var picker4: UIPickerView!
    @IBOutlet weak var picker5: UIPickerView!
    @IBOutlet weak var picker6: UIPickerView!
    
    
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
       
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if name3 == "Alabama" || name3 == "LSU" {
            return grades1[row]
        }
        else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
            return grades2[row]
        }
        else if name3 == "Georgia" || name3 == "Ole Miss" {
            return grades3[row]
        }
        else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                return grades4[row]
        }
        else {
            return grades5[row]
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if name3 == "Alabama" || name3 == "LSU" {
            return grades1.count
        }
        else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
            return grades2.count
        }
        else if name3 == "Georgia" || name3 == "Ole Miss" {
            return grades3.count
        }
        else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
            return grades4.count
        }
        else {
            return grades5.count
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == picker1 {
       
            if name3 == "Alabama" || name3 == "LSU" {
                grade1 = grades1[row]
                   }
            else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                grade1 = grades2[row]
            }
            else if name3 == "Georgia" || name3 == "Ole Miss" {
                grade1 = grades3[row]
            }
            else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                 grade1 = grades4[row]
            }
            else {
                grade1 = grades5[row]
            }
        }
        
        else if pickerView == picker2 {
        
             if name3 == "Alabama" || name3 == "LSU" {
                 grade2 = grades1[row]
                    }
             else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                 grade2 = grades2[row]
             }
             else if name3 == "Georgia" || name3 == "Ole Miss" {
                 grade2 = grades3[row]
             }
            else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                 grade2 = grades4[row]
             }
             else {
                 grade2 = grades5[row]
             }
         }
        
        else if pickerView == picker3 {
        
             if name3 == "Alabama" || name3 == "LSU" {
                 grade3 = grades1[row]
                    }
             else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                 grade3 = grades2[row]
             }
             else if name3 == "Georgia" || name3 == "Ole Miss" {
                 grade3 = grades3[row]
             }
            else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                 grade3 = grades4[row]
            }
             else {
                 grade3 = grades5[row]
             }
         }
        
        else if pickerView == picker4 {
        
             if name3 == "Alabama" || name3 == "LSU" {
                 grade4 = grades1[row]
                    }
             else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                 grade4 = grades2[row]
             }
             else if name3 == "Georgia" || name3 == "Ole Miss" {
                 grade4 = grades3[row]
             }
            else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                grade4 = grades4[row]
            }
             else {
                 grade4 = grades5[row]
             }
         }
        
        else if pickerView == picker5 {
            
             if name3 == "Alabama" || name3 == "LSU" {
                 grade5 = grades1[row]
                    }
             else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                 grade5 = grades2[row]
             }
             else if name3 == "Georgia" || name3 == "Ole Miss" {
                 grade5 = grades3[row]
             }
            else if name3 == "Auburn" || name3 == "Texas A&M" || name3 == "Mississippi State" {
                 grade5 = grades4[row]
            }
             else {
                 grade5 = grades5[row]
             }
         }
        
        else {
            if name3 == "Alabama" || name3 == "LSU" {
                grade6 = grades1[row]
                   }
            else if name3 == "Arkansas" || name3 == "Kentucky" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" {
                grade6 = grades2[row]
            }
            else if name3 == "Georgia" || name3 == "Ole Miss" {
                grade6 = grades3[row]
            }
            else {
                grade6 = grades4[row]
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
        
       @IBAction func calculateGPA(_ sender: Any) {
        if let c1 = Double(credit1.text!) {
            cv1 = c1
        }
      
        if let c2 = Double(credit2.text!) {
            cv2 = c2
        }
       
        if let c3 = Double(credit3.text!) {
           cv3 = c3
        }
        
        if let c4 = Double(credit4.text!) {
            cv4 = c4
        }
        
        if let c5 = Double(credit5.text!) {
            cv5 = c5
        }
        
        if let c6 = Double(credit6.text!) {
            cv6 = c6
        }
        
        if let initialGPA = Double(cumulativeGPA.text!) {
            iGPA = initialGPA
        }
        
        if let creditNum = Double(totalCredits.text!) {
            credit = creditNum
        }
        
    
        
        let g1: Double = convertLetter(value: grade1)
        let g2: Double = convertLetter(value: grade2)
        let g3: Double = convertLetter(value: grade3)
        let g4: Double = convertLetter(value: grade4)
        let g5: Double = convertLetter(value: grade5)
        let g6: Double = convertLetter(value: grade6)
        
        let sHours = cv1 + cv2 + cv3 + cv4 + cv5 + cv6
        let sGPA = (cv1 * g1 + cv2 * g2 + cv3 * g3 + cv4 * g4 + cv5 * g5 + cv6 * g6) / (sHours)
        semesterGPA.text = String(round(100*sGPA)/100)
        
        let cGPA = (sGPA * sHours + iGPA * credit) / (sHours + credit)
        updatedGPA.text = String(round(100*cGPA)/100)
        
        
        
        
        
        
        //c2 = Double(credit1.text!)!
        
               //let c2: Double = Double(credit2.text!)!
               //let c3: Double = Double(credit3.text!)!
               //let c4: Double = Double(credit4.text!)!
               //let c5: Double = Double(credit5.text!)!
               //let c6: Double = Double(credit6.text!)!
        
        
               
               
        
               
           }
    
    func convertLetter(value: String) -> Double {
        if value == "A" {
            return 4.0
        }
        if value == "B" {
            return 3.0
        }
        if value == "C" {
            return 2.0
        }
        if value == "D" {
            return 1.0
        }
        if value == "F" {
            return 0.0
        }
        if name3 == "Alabama" || name3 == "Arkansas" {
            if value == "A+" {
                return 4.33
            }
            if value == "A-" {
                return 3.67
            }
            if value == "B+" {
                return 3.33
            }
            if value == "B-" {
                return 2.67
            }
            if value == "C+" {
                return 2.33
            }
            if value == "C-" {
                return 1.67
            }
            if value == "D+" {
                return 1.33
            }
            if value == "D-" {
                return 0.67
            }
        }
        if name3 == "Florida" || name3 == "South Carolina" {
            if value == "B+" {
                return 3.5
            }
            if value == "C+" {
                return 2.5
            }
            if value == "D+" {
                return 1.5
            }
        }
        if name3 == "Georgia" || name3 == "Kentucky" || name3 == "LSU" || name3 == "Missouri" || name3 == "Tennessee" || name3 == "Vanderbilt" || name3 == "Ole Miss" {
            if value == "A+" {
                return 4.3
            }
            if value == "A-" {
                return 3.7
            }
            if value == "B+" {
                return 3.3
            }
            if value == "B-" {
                return 2.7
            }
            if value == "C+" {
                return 2.3
            }
            if value == "C-" {
                return 1.7
            }
            if (name3 != "Georgia" && name3 != "Ole Miss") {
                if value == "D+" {
                    return 1.3
                }
                if value == "D-" {
                    return 0.7
                }
            }
                
        }
        return 0.0
    }
           
                              
        

    
    
     
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}




