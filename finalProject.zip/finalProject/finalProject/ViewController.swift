//
//  ViewController.swift
//  finalProject
//
//  Created by Maggie Blanton on 7/1/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var picker: UIPickerView!
    var schoolSelected = " "
    
    @IBOutlet var label: UILabel!
    
    @IBOutlet var selectButton: UIButton!
    
    
    let schools = ["Alabama", "Arkansas", "Auburn", "Florida", "Georgia", "Kentucky", "LSU", "Mississippi State", "Missouri", "Ole Miss", "South Carolina", "Tennessee", "Texas A&M", "Vanderbilt"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return schools[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return schools.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        schoolSelected = schools[row]
    }
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func selectSchool(_ sender: Any) {
        performSegue(withIdentifier: "schoolName", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let view = segue.destination as! ViewController2
        view.name2 = self.schoolSelected
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: "secLogo")
        self.view.backgroundColor = UIColor(red: 0.00, green: 0.29, blue: 0.55, alpha: 1.00)
        selectButton.backgroundColor = UIColor(red: 1.00, green: 0.82, blue: 0.28, alpha: 1.00)
        selectButton.setTitleColor(UIColor(red: 0.00, green: 0.29, blue: 0.55, alpha: 1.00), for: .normal)
        schoolSelected = "Alabama"
        label.textColor = .white
        picker.setValue(UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00), forKey: "textColor")
        
       
    }
    
  
}

