//
//  ViewController4.swift
//  finalProject
//
//  Created by Maggie Blanton on 7/2/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController4: UIViewController, UITextFieldDelegate {
    var name3 = " "
    var currGPA: Double = 0.0, cred: Double = 0.0, pts: Double = 0.0, hrs: Double = 0.0, cumGPA: Double = 0.0

    @IBOutlet var cumulativeGPA: UITextField!
    
    @IBOutlet var credits: UITextField!
    
    @IBOutlet var points: UITextField!
    
    @IBOutlet var hours: UITextField!
    
    @IBOutlet var gpa: UITextField!
    
 

    @IBOutlet var desiredGPA: UITextField!
    
    @IBOutlet var calculateButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cumulativeGPA.delegate = self
        self.credits.delegate = self
        self.points.delegate = self
        self.hours.delegate = self
        self.gpa.delegate = self
        
        cumulativeGPA.backgroundColor = .white
        cumulativeGPA.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        credits.backgroundColor = .white
        credits.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        points.backgroundColor = .white
        points.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        hours.backgroundColor = .white
        hours.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        gpa.backgroundColor = .white
        gpa.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        desiredGPA.backgroundColor = .white
        desiredGPA.attributedPlaceholder = NSAttributedString(string: "0.0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        
        
            if name3 == "Alabama" {
            self.view.backgroundColor = UIColor(red: 0.65, green: 0.05, blue: 0.19, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(.black, for: .normal)
           }
           if name3 == "Arkansas" {
            self.view.backgroundColor = UIColor(red: 0.62, green: 0.13, blue: 0.21, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(.black, for: .normal)
           }
           if name3 == "Auburn" {
               self.view.backgroundColor = UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.97, green: 0.40, blue: 0.13, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.02, green: 0.14, blue: 0.30, alpha: 1.00), for: .normal)
           }
           if name3 == "Florida" {
               self.view.backgroundColor = UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00)
             calculateButton.backgroundColor = UIColor(red: 0.98, green: 0.34, blue: 0.09, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.00, green: 0.19, blue: 0.53, alpha: 1.00), for: .normal)
           }
           if name3 == "Georgia" {
               self.view.backgroundColor = UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00)
             calculateButton.backgroundColor = UIColor(red: 0.73, green: 0.01, blue: 0.16, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.17, green: 0.16, blue: 0.16, alpha: 1.00), for: .normal)
           }
           if name3 == "Kentucky" {
               self.view.backgroundColor = UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.00, green: 0.20, blue: 0.62, alpha: 1.00), for: .normal)
           }
           if name3 == "LSU" {
            self.view.backgroundColor = UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00)
            calculateButton.backgroundColor = UIColor(red: 0.96, green: 0.85, blue: 0.42, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.27, green: 0.11, blue: 0.49, alpha: 1.00), for: .normal)
           }
           if name3 == "Mississippi State" {
               self.view.backgroundColor = UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.36, green: 0.09, blue: 0.15, alpha: 1.00), for: .normal)
           }
           if name3 == "Missouri" {
            self.view.backgroundColor = .black
              calculateButton.backgroundColor = UIColor(red: 0.97, green: 0.82, blue: 0.28, alpha: 1.00)
            calculateButton.setTitleColor(.black, for: .normal)
           }
           if name3 == "Ole Miss" {
               self.view.backgroundColor = UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00)
             calculateButton.backgroundColor = UIColor(red: 0.98, green: 0.00, blue: 0.24, alpha: 1.00)
            calculateButton.setTitleColor(UIColor(red: 0.12, green: 0.26, blue: 0.49, alpha: 1.00), for: .normal)
           }
           if name3 == "South Carolina" {
               self.view.backgroundColor = UIColor(red: 0.45, green: 0.00, blue: 0.04, alpha: 1.00)
            calculateButton.backgroundColor = .white
             calculateButton.setTitleColor(.black, for: .normal)
           }
           if name3 == "Tennessee" {
               self.view.backgroundColor = UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00)
            calculateButton.backgroundColor = .white
             calculateButton.setTitleColor(UIColor(red: 1.00, green: 0.51, blue: 0.00, alpha: 1.00), for: .normal)
           }
           if name3 == "Texas A&M" {
               self.view.backgroundColor = UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00)
            calculateButton.backgroundColor = .white
            calculateButton.setTitleColor(UIColor(red: 0.31, green: 0.00, blue: 0.00, alpha: 1.00), for: .normal)
           }
           if name3 == "Vanderbilt" {
               self.view.backgroundColor = .black
            calculateButton.backgroundColor = UIColor(red: 0.70, green: 0.63, blue: 0.46, alpha: 1.00)
            calculateButton.setTitleColor(.black, for: .normal)
           }

        // Do any additional setup after loading the view.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
       }
    
    
    @IBAction func calculate(_ sender: Any) {
        if let c1 = Double(cumulativeGPA.text!) {
            currGPA = c1
        }
        if let c2 = Double(credits.text!) {
            cred = c2
        }
        if let c3 = Double(points.text!) {
            pts = c3
        }
        if let c4 = Double(hours.text!) {
            hrs = c4
        }
        
        let dGPA = (currGPA + pts) 
        desiredGPA.text = String(round(100*dGPA)/100)
        
        let cGPA = (dGPA * (cred + hrs) - (currGPA * cred)) / hrs
        gpa.text = String(round(100*cGPA)/100)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
