//
//  ViewController.swift
//  comp5970-project1b
//
//  Created by Maggie Blanton on 6/6/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: "secLogo")
        
    }
    
    
    @IBAction func auburnButton(_ sender: UIButton) {
        imageView.image = UIImage(named: "auburnLogo")
    }
    
    
   
    @IBAction func secButton(_ sender: UIButton) {
        imageView.image = UIImage(named: "secLogo")
    }
    
    
    
    @IBAction func alabamaButton(_ sender: UIButton) {
        imageView.image = UIImage(named: "alabamaLogo")
    }
    


}

