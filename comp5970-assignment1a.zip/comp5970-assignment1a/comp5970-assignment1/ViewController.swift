//
//  ViewController.swift
//  comp5970-assignment1
//
//  Created by Maggie Blanton on 5/26/20.
//  Copyright © 2020 edu.auburn.csse.comp5970. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

